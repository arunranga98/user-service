insert into user(id,username,password,address,phone) values(1001L,'Arun','james','Bangalore',9894501938);
insert into user(id,username,password,address,phone) values(1002L,'AJ','AJ1223','chennai',9894501938);
insert into user(id,username,password,address,phone) values(1003L,'yash','yash123','mumbai',9894501938);
insert into user(id,username,password,address,phone) values(1004L,'dilip','Dilip123','pune',9894501938);
insert into user(id,username,password,address,phone) values(1005L,'BD','BD123','Hydrabad',9894501938);
